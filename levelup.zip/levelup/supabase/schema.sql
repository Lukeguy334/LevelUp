-- LevelUp schema. Run this once in Supabase SQL editor.
-- Single-user app, but uses real Supabase Auth so it's safe to put the URL/key in client code.

create table if not exists profiles (
  id uuid references auth.users primary key,
  height_cm numeric,
  weight_kg numeric,
  sex text check (sex in ('male','female')),
  workouts_per_week int default 4,
  weight_goal_direction text check (weight_goal_direction in ('gain','lose','maintain')) default 'maintain',
  weight_goal_rate text check (weight_goal_rate in ('slow','moderate','fast')) default 'moderate',
  calorie_goal int,
  calorie_goal_auto boolean default true,
  water_goal_ml int,
  water_goal_auto boolean default true,
  xp int default 0,
  level int default 1,
  coins int default 0,
  med_names text[] default '{}',
  onboarded boolean default false,
  created_at timestamptz default now()
);

create table if not exists weight_logs (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users not null,
  logged_on date not null default current_date,
  weight_kg numeric not null,
  created_at timestamptz default now()
);

create table if not exists prs (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users not null,
  exercise_name text not null,
  weight_kg numeric not null,
  reps int not null,
  achieved_on date not null default current_date,
  unique (user_id, exercise_name)
);

create table if not exists workout_logs (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users not null,
  logged_on date not null default current_date,
  muscle_groups text[],
  sets jsonb not null, -- [{exercise, muscle_group, weight_kg, reps, is_pr}]
  duration_min int,
  xp_earned int default 0,
  coins_earned int default 0,
  created_at timestamptz default now()
);

create table if not exists daily_logs (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users not null,
  logged_on date not null default current_date,
  calories_eaten int,
  water_ml int default 0,
  meds_taken jsonb default '{}', -- {"Vitamin D": true, ...}
  calorie_goal_rewarded boolean default false,
  water_goal_rewarded boolean default false,
  unique (user_id, logged_on)
);

create table if not exists weekly_schedules (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users not null,
  week_start date not null,
  plan jsonb not null, -- {"Mon": {"muscle_groups": [...], "exercises":[...]}, ...}
  unique (user_id, week_start)
);

create table if not exists shop_items (
  id text primary key,
  name text not null,
  category text check (category in ('hat','outfit','pet','accessory')) not null,
  cost int not null,
  min_level int default 1,
  emoji text
);

create table if not exists inventory (
  user_id uuid references auth.users not null,
  item_id text references shop_items not null,
  equipped boolean default false,
  acquired_at timestamptz default now(),
  primary key (user_id, item_id)
);

-- Row Level Security: everyone can only touch their own rows
alter table profiles enable row level security;
alter table weight_logs enable row level security;
alter table prs enable row level security;
alter table workout_logs enable row level security;
alter table daily_logs enable row level security;
alter table weekly_schedules enable row level security;
alter table inventory enable row level security;
alter table shop_items enable row level security;

create policy "own profile" on profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "own weight logs" on weight_logs for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own prs" on prs for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own workout logs" on workout_logs for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own daily logs" on daily_logs for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own schedules" on weekly_schedules for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own inventory" on inventory for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "read shop" on shop_items for select using (true);

insert into shop_items (id, name, category, cost, min_level, emoji) values
  ('hat_cap', 'Backwards Cap', 'hat', 50, 1, '🧢'),
  ('hat_headband', 'Sweat Headband', 'hat', 50, 1, '🎽'),
  ('hat_crown', 'Gains Crown', 'hat', 400, 8, '👑'),
  ('hat_horns', 'Beast Mode Horns', 'hat', 350, 6, '😈'),
  ('outfit_tank', 'Stringer Tank', 'outfit', 120, 2, '🎽'),
  ('outfit_hoodie', 'Winter Bulk Hoodie', 'outfit', 200, 4, '🧥'),
  ('outfit_gold', 'Gold Singlet', 'outfit', 500, 10, '🥇'),
  ('pet_dog', 'Gym Dog', 'pet', 250, 3, '🐕'),
  ('pet_cat', 'Spotter Cat', 'pet', 250, 3, '🐈'),
  ('pet_dragon', 'Motivation Dragon', 'pet', 800, 12, '🐉'),
  ('accessory_shades', 'Gym Shades', 'accessory', 80, 1, '🕶️'),
  ('accessory_chain', 'Gains Chain', 'accessory', 300, 5, '⛓️'),
  ('accessory_belt', 'Lifting Belt', 'accessory', 150, 3, '🥋')
on conflict (id) do nothing;
